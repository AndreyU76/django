from django.apps import AppConfig


class MainappConfig(AppConfig):
    name = 'mainapp'
